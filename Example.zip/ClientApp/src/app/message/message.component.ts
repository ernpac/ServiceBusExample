import { Component, OnInit } from '@angular/core';
import { HomeService } from '../home/home.service';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.css']
})
export class MessageComponent implements OnInit {
  messages: Array<string>;
  constructor(private _messageService: HomeService) { }

  ngOnInit() {
  }

  getMessages () {    
    this._messageService.getMessages().subscribe(data => {
      this.messages = data;
    });
  }

}
