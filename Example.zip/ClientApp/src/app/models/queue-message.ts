export class QueueMessage {
    Id: number;
    CustomerName: string;
    CustomerAddress: string;
    ShipType: string;
    BoxOnly: boolean;
    constructor(_id: number, _customerName: string, _customerAddress: string, _shipType: string, _boxOnly: boolean)
    {
        this.Id = _id;
        this.CustomerName = _customerName;
        this.CustomerAddress = _customerAddress;
        this.ShipType = _shipType;
        this.BoxOnly = _boxOnly;
    }
}
