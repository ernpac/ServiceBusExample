import { Component } from '@angular/core';
import { HomeService } from './home.service';
import { QueueMessage } from '../models/queue-message';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html'
})
export class HomeComponent {
  results: Array<string>;
  messages: Array<any>;
  shipments: Array<QueueMessage>;
  response: any;
  constructor(private _messageService: HomeService) { 
    this.shipments = new Array<QueueMessage>();
    this.shipments.push(new QueueMessage(1, "Ernie Dunn", "123 Main St Kingsport, Tn 37660", "Next Day Air", false));
    this.shipments.push(new QueueMessage(2, "James Knettel", "125 Main St Atlanta, Ga 12121", "Ground", true));
    this.shipments.push(new QueueMessage(3, "Dave Grohl", "123 Foo St Los Angeles, Ca 50050", "Next Day Air", false));
    this.shipments.push(new QueueMessage(4, "Ed Vedder", "123 Pearl St Seattle, Wa 98745", "2nd Day", true));
    this.shipments.push(new QueueMessage(5, "William Ryan Key", "123 Ocean Ave Hollywoord, Ca 50049", "Next Day Air", false));
  }

  postShipments() {
    this._messageService.postShipments(this.shipments).subscribe(data => {
      console.log(data);
      this.response = data;
    });
  }
}
