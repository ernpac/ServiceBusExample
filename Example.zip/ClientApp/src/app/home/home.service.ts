import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { QueueMessage } from '../models/queue-message';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class HomeService {
  public API = 'http://localhost:8080/api';
  constructor(private http: HttpClient) { }

  // postMessage(message: string): Observable<Array<string>> {
  //   var msg = new Array<QueueMessage>();
  //   msg.push(new QueueMessage(message));
  //   return this.http.post<Array<string>>(this.API + '/ServiceBusDemo/', msg, { headers: httpOptions.headers });
  // }

  postShipments(shipments: Array<QueueMessage>): Observable<any> {
    return this.http.post(this.API + '/ServiceBusDemo', shipments);
  }

  getMessages(): Observable<Array<string>> {
    return this.http.get<Array<string>>(this.API + "/ServiceBusDemo");
  }
}
