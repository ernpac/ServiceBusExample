﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiceBus2.Models
{
    public class QueueMessage
    {
        public int Id { get; set; }
        public string CustomerName { get; set; }
        public string CustomerAddress { get; set; }
        public string ShipType { get; set; }
        public Boolean BoxOnly { get; set; }
    }
}