﻿using Microsoft.ServiceBus.Messaging;
using ServiceBus2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace ServiceBus2.Controllers
{
    public class ServiceBusDemoController : ApiController
    {
        private static string ServiceBusConnectionString = "Endpoint=sb://servicebusnp.optum.com/EUTSDOTR-Shipping;StsEndpoint=https://servicebusnp.optum.com:9355/EUTSDOTR-Shipping;RuntimePort=9354;ManagementPort=9355;SharedAccessKeyName=Admin;SharedAccessKey=lmR3Y274IHd+omkB5viBkmJ7Fi/+irYB1KKDo9WtCQI=";
        private static string QueueName = "testqueue-ernie";
        //static IMessageReceiver messageReceiver;

        [HttpPost]
        public async Task<IHttpActionResult> PostToServiceBus([FromBody] List<QueueMessage> shipments)
        {
            var client = QueueClient.CreateFromConnectionString(ServiceBusConnectionString, QueueName);
            BrokeredMessage msg = null;
            string ship = "";
            string shipped = "";
            foreach (QueueMessage shipment in shipments)
            {
                ship = new JavaScriptSerializer().Serialize(shipment);
                msg = new BrokeredMessage(ship);
                await client.SendAsync(msg);
                shipped += "Message Id: " + msg.MessageId + " | " + msg.GetBody<string>() + "<br />";
            }

            //await SendMessagesAsync(messages);
            return Content(HttpStatusCode.Accepted, shipped);
        }

        [HttpGet]
        public async Task<IHttpActionResult> GetMessages()
        {
            var messages = new List<string>();
            var client = QueueClient.CreateFromConnectionString(ServiceBusConnectionString, QueueName);
            while(client.Peek() != null)
            {
                var brokeredMessage = await client.ReceiveAsync();
                brokeredMessage.Complete();
                //brokeredMessage.ReplyTo(); - could we use this to pass messages back to a "processed" queue?
                messages.Add("Shipment of " + brokeredMessage.MessageId + " Processed: " + brokeredMessage.GetBody<string>() + "<br />");
            }

            return Ok(messages);
        }
    }
}
